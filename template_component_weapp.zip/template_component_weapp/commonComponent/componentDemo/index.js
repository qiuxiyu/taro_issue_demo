Component({
  /**
   * 组件的属性列表
   */
  properties: {
    appId: String
  },

  /**
   * 组件的初始数据
   */
  data: {
   
  },

  ready: function() {
    console.log("this.appId:",this.data.appId);
    console.log("this.properties:",this.properties.appId);
  }
})