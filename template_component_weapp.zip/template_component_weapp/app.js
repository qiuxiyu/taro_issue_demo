

App({
  onLaunch: function (options) {

  },
  globalData: {
    statusBarHeight: "",
    titleBarHeight: ""
  }
})
