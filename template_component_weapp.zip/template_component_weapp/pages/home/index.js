Page({
  data: {

  },
  // 分享
  onShareAppMessage: function () {
    return {
      title: '携程旅行--酒店机票火车票汽车票预订',
      desc: '欢迎使用携程旅行，预定酒店机票火车票汽车票！'
    }
  },

  onLoad: function (opt) {


  }
});