

Page({
    data: {

    },

    onReady: function () {
       console.log("ready");
    }

})