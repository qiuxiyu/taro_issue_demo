// components/float.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {

  },

  pageLifetimes: {
    // 组件所在页面的生命周期函数
    show: function () { 
      console.log("%c pageLifetimes page show", "color:red;")
    },
    hide: function () { 
      console.log("%c pageLifetimes page hide", "color:red;")
    },
    resize: function () { 
      console.log("%c pageLifetimes page resize", "color:red;")
    },
  },
  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {

  }
})
