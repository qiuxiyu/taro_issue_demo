"use strict";
(wx["tripTaroGlobal81"] = wx["tripTaroGlobal81"] || []).push([["comp"],{},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
/******/ __webpack_require__.O(0, ["taro","common"], function() { return __webpack_exec__("./node_modules/@tarojs/webpack5-runner/dist/template/comp.js"); });
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);
//# sourceMappingURL=comp.js.map