require('./taroBase/app.js')
// Page = function(){
//   try{
//     throw new Error(111);
//   }catch (e) {
//     console.log(e.stack);
//   }
// }
App({
  onError(msg) {

  },
  onLaunch: function (options) {

  },
  globalData: {
    statusBarHeight: "",
    titleBarHeight: ""
  },
  onShow: function (options) {

  },
  onHide: function (options) {

  }
})
