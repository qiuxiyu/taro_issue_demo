export default {
  navigationBarTitleText: '占位页面',
}
