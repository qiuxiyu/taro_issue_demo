// eslint-disable-next-line no-undef
Component({
	/**
	 * 组件的属性列表
	 */
	properties: {
		testdata: {
			type: Object,
			value: {},
		},
	},
});
