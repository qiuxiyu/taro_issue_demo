import React from 'react'
import { View } from '@tarojs/components'
import "./index.scss";
import Taro from '@tarojs/taro';

export default class Index extends React.Component {
  constructor() {
    super();
  }
  componentDidMount () {
    // logRaw()
    console.log(222);
  }
  navHome = () => {
    Taro.navigateTo({
      url: "/pages/home/helloword"
    });
  }
  render () {
    return (
      <View className='index'>
        <ofloat />
        <View onClick={this.navHome}>跳转至下一个页面</View>
      </View>
    )
  }
}
