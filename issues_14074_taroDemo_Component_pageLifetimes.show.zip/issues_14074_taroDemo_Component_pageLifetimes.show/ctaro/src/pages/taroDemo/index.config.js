export default {
  navigationBarTitleText: 'demo',
  usingComponents: {
    "ofloat": "@miniapp/components/float"
  }
}
